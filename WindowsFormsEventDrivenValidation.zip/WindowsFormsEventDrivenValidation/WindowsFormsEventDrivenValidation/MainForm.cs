﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsValidation
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }
        private readonly Regex nameRegex = new Regex("^[A-Z][A-Za-z]+([ ][A-Z][A-Za-z]+){1,2}$");
        private readonly string nameErrorNote =
            "[First name] [Middle name] [Last name].\n" +
            "[Middle name] is optional.\n" +
            "Each part starts with capital letter and continuues with at least one letter.\n" +
            "e.g., Bella Yafa Choen";

        private readonly Regex phoneRegex = new Regex("^05[0-9]-[0-9]{4}-[0-9]{3}$");
        private readonly string phoneErrorNote =
            "[3 prefix numbers]-[4 numbers]-[3 numbers]\n" +
            "e.g., 052-4444-333";

        private readonly Regex emailRegex = new Regex("^[a-z]{3,}@[a-z]{3,}.[a-z]{2,3}$");
        private readonly string emailErrorNote =
            "[local name]@[host name].[DNS label].\n" +
            "[local name] should contain at least 3 small letters.\n" +
            "[host name] should contain at least 3 small letters.\n" +
            "[DNS label] should contain between 2 and 3 small letters.\n" +
            "e.g., bella@yafa.ch";

        private void MainForm_Load(object sender, EventArgs e)
        {
            helpProvider.SetHelpString(txtName, nameErrorNote);
            helpProvider.SetHelpString(txtPhone, phoneErrorNote);
            helpProvider.SetHelpString(txtEmail, emailErrorNote);
        }

        private void TxtName_Validating(object sender, CancelEventArgs e)
        {
            errorProvider.SetError(txtName, "");
            if (txtName.Text != "")
            {
                if (!nameRegex.IsMatch(txtName.Text))
                {
                    txtName.Select(0, txtName.Text.Length);
                    errorProvider.SetError(txtName, nameErrorNote);
                    txtName.Focus();
                }
                else
                {
                    var (firstName, middleName, surnName) = SplitName(txtName.Text);
                    MessageBox.Show(
                        "First name: " + firstName + "\n" +
                        "Middle name: " + (middleName ?? "none") + "\n" +
                        "Surnname: " + surnName);
                }
            }
        }

        private (string, string, string) SplitName(string text)
        {
            string[] words = txtName.Text.Split(' ');
            string firstName = words[0];
            string middleName;
            string surnName;
            if (words.Length == 2)
            {
                middleName = null;
                surnName = words[1];
            }
            else
            {
                middleName = words[1];
                surnName = words[2];
            }
            return (firstName, middleName, surnName);
        }

        private void TxtPhone_Validating(object sender, CancelEventArgs e)
        {
            errorProvider.SetError(txtPhone, "");
            if (txtPhone.Text != "")
            {
                if (!phoneRegex.IsMatch(txtPhone.Text))
                {
                    txtPhone.Select(0, txtPhone.Text.Length);
                    errorProvider.SetError(txtPhone, phoneErrorNote);
                    txtPhone.Focus();
                }
                else
                {
                    string[] words = txtPhone.Text.Split('-');
                    string prefix = words[0];
                    string number = words[1] + words[2];
                    MessageBox.Show(
                        "prefix: " + prefix + "\n" +
                        "Number: " + number);
                }
            }
        }
        private void TxtEmail_Validating(object sender, CancelEventArgs e)
        {
            errorProvider.SetError(txtEmail, "");
            if (txtEmail.Text != "")
            {
                if (!emailRegex.IsMatch(txtEmail.Text))
                {
                    txtEmail.Select(0, txtEmail.Text.Length);
                    errorProvider.SetError(txtEmail, emailErrorNote);
                    txtEmail.Focus();
                }
                else
                {
                    string[] words = txtEmail.Text.Split('@', '.');
                    string localName = words[0];
                    string hostName = words[1];
                    string dnsLabel = words[2];
                    MessageBox.Show(
                        "Local name : " + localName + "\n" +
                        "Host Name: " + hostName + "\n" +
                        "DNS label: " + dnsLabel);
                }
            }
        }
        private void BtnSubmit_Click(object sender, EventArgs e)
        {
            if (txtName.Text != "" && errorProvider.GetError(txtName) == "" &&
                txtPhone.Text != "" && errorProvider.GetError(txtPhone) == "" &&
                txtEmail.Text != "" && errorProvider.GetError(txtEmail) == "")
            {
                MessageBox.Show("Submited");
                txtName.Clear();
                txtPhone.Clear();
                txtEmail.Clear();
            }
            else
            {
                MessageBox.Show("Can't submit. There are some input errors.");
            }
        }
    }
}
